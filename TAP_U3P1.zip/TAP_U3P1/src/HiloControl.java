
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.Timer;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author xirax
 */
public class HiloControl extends Thread{
    NewJFrame puntero;
    int contador=1;
    int r,g,b;
    protected boolean pausado=false;
    protected boolean ejecutar=true;
    String[] frases = new String[]{
        "Cáete siete veces, levántate ocho","Un hoy vale dos mañanas",
        "El pasado está escrito en la memoria y el futuro presente en el deseo","La vida empieza cada cinco minutos",
        "Las palabras cera, las obras acero","Lo que uno puede llegar a ser, uno debe serlo ",
        "Si vivir es solo soñar, hagamos el bien soñando","El poder de la imaginación nos hace infinitos",
        "El Indulto es para los criminales, no para los defensores de la patria","¡Seamos realistas, pidamos lo imposible!",
        "No hay árbol que el viento no haya sacudido","La libertad muere si no se usa",
        "Las emociones inexpresadas nunca mueren. Son enterradas vivas y salen más tarde de peores formas","Donde las palabras fallan la música habla",
        "Hoy es el día de mañana que tanto te preocupaba ayer","No se puede encontrar la paz evitando la vida",
        "El mayor imperio es el imperio de uno mismo","La vida es como el jazz... mejor si es improvisada",
        "La mayor declaración de amor es la que no se hace, el hombre que siente mucho habla poco","Todo lo que se puede imaginar es real",
        "Los retos hacen que la vida sea interesante. Superarlos es lo que hace que la vida tenga sentido","El conocimiento es un antídoto para el miedo",
        "Si todo el año fuese fiesta, divertirse sería más aburrido que trabajar","El amor es un humo hecho con los vapores de los suspiros",
        "La cosa más difícil es conocernos a nosotros mismos; la más fácil es hablar mal de los demás","Un buen viajante no tiene planes",
        "Sentir dolor es inevitable. Sufrir es opcional","Lo que no puedo crear, no lo entiendo",
        "Es una locura odiar a todas las rosas porque una te pinchó. Renunciar a todos tus sueños porque uno de ellos no se realizó","De las dificultades nacen milagros",
        "Cada santo tiene un pasado y todo pecador tiene un futuro","El amor es un mejor maestro que el deber",
        "El presente es un regalo","La vida es la flor de la que el amor es la miel",
        "Si buscas resultados distintos, no hagas siempre lo mismo","Mira atrás y sonríe ante los peligros pasados",
        "Cria cuervos y te sacaran los ojos","Vivimos en un arcoiris de caos",
        "Aunque supiera que mañana el mundo se va a desintegrar, todavía plantaría mi manzano","A veces el corazón ve lo que es invisible a los ojos",
        "Siempre hay algo de locura en el amor, pero siempre hay un poco de razón en la locura","Nos convertimos en lo que pensamos"
        
    };
    public HiloControl(NewJFrame  p){
        this.puntero=p;
    }
    public void pausar(){
        pausado = !pausado;
    }
    public void detener(){
        ejecutar=false;
    }
    @Override
    public void run(){
        while(ejecutar){
            try {
                if(estaDespausado()){
                    puntero.jLabel2.setText(frases[contador]);
                    puntero.jLabel1.setText("Contador Hilo: "+contador);
                    contador++;
                    if(contador == frases.length){
                        contador=0;
                    }
                }
                sleep(20000);
            } catch (InterruptedException ex) {
                Logger.getLogger(HiloControl.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    private boolean estaDespausado() {
        return !pausado;
    }
}
